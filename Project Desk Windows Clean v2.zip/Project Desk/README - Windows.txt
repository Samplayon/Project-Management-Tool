Project Desk for Windows

1. Right-click the ZIP file and choose Extract All. Do not run the launcher from inside the ZIP preview.
2. Open the extracted Project Desk folder.
3. Double-click Launch Project Desk.cmd.
4. Leave the black command window open while using the app.
5. The app should open automatically at http://127.0.0.1:8000. If it does not, open that address manually after the command window says Project Desk is running.

If the launcher says Python 3 or Node.js was not found, install Python 3 from https://www.python.org/downloads/windows/. During installation, check Add python.exe to PATH. Then run Launch Project Desk.cmd again.

If the browser says it cannot reach the page, check that the black command window is still open. If it closed, run Launch Project Desk.cmd again and read the message in that window.

Project data is saved locally in data\project-data.csv. This copy starts with a clean empty CSV.
