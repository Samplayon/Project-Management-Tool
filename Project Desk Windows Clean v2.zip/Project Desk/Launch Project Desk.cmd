@echo off
setlocal
cd /d "%~dp0"

if not exist "server.py" (
  echo Project Desk was not opened from the extracted project folder.
  echo.
  echo Right-click the ZIP file, choose Extract All, then open the extracted Project Desk folder.
  echo After that, double-click Launch Project Desk.cmd again.
  echo.
  pause
  exit /b 1
)

if not defined PORT set "PORT=8000"
set "URL=http://127.0.0.1:%PORT%"
set "SERVER_CMD="

where py >nul 2>nul
if not errorlevel 1 (
  py -3 -c "import sys" >nul 2>nul
  if not errorlevel 1 set "SERVER_CMD=py -3 server.py"
)

if not defined SERVER_CMD (
  where python >nul 2>nul
  if not errorlevel 1 (
    python -c "import sys" >nul 2>nul
    if not errorlevel 1 set "SERVER_CMD=python server.py"
  )
)

if not defined SERVER_CMD (
  where node >nul 2>nul
  if not errorlevel 1 (
    node -e "process.exit(0)" >nul 2>nul
    if not errorlevel 1 set "SERVER_CMD=node server.js"
  )
)

if not defined SERVER_CMD (
  echo Project Desk could not start because Python 3 or Node.js was not found.
  echo.
  echo Install Python 3 from https://www.python.org/downloads/windows/
  echo Make sure to check "Add python.exe to PATH" during installation.
  echo Then run this launcher again.
  echo.
  pause
  exit /b 1
)

echo Starting Project Desk...
echo.
echo Leave this window open while you use the app.
echo When you are done, close this window or press Ctrl+C to stop Project Desk.
echo.
echo Opening %URL% after the local server is ready...
echo.

start "" /min powershell -NoProfile -ExecutionPolicy Bypass -Command "$url = '%URL%'; for ($i = 0; $i -lt 45; $i++) { try { Invoke-WebRequest -UseBasicParsing -TimeoutSec 1 $url ^| Out-Null; Start-Process $url; exit 0 } catch { Start-Sleep -Seconds 1 } }; Write-Host 'Project Desk did not respond. Check the launcher window for the server error.'; Start-Sleep -Seconds 8"

%SERVER_CMD%

echo.
echo Project Desk stopped.
pause
endlocal
